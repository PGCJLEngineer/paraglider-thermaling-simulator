import pygame
import math
import time
import random



   
#-----------------------------------------------------------------------
# REVISED CLASSES
# Hopefully a well sorted out game architecture this time
#-----------------------------------------------------------------------

class world(object):
    def __init__(self):
        
        #Max_No_of_Thermals/sinks
        self.mnot = 6 # Default = 6!
        self.mnos = 6 # Default = 6
        self.sf = 0.2   # define LIFT SCALE FACTOR FOR SCREEN SIZE
        
        self.all_thermals_visible = True
        self.all_sinks_visible = True
        
        random.seed(time.time()) # Initailize random number generator
        self.size = pygame.display.Info().current_w, pygame.display.Info().current_h
        print "Pygame Dimensions ", self.size       
        self.font = pygame.font.SysFont('FreeMono', 25, True, False)  
               
        self.BLACK = (0, 0, 0)
        self.WHITE = (255, 255, 255)
        self.YELLOW = (255,255,0)        
        
        #self.north_pointer = pygame.image.load("resources/north_pointer.png")
        
        self.background = pygame.image.load("resources/aerial-view.png")

        self.number_of_thermals = random.randint(1,self.mnot)  # Sets default number of thermals
        print "No of thermals", self.number_of_thermals
        
        self.number_of_sinks = random.randint(1,self.mnos)  # Sets default number of thermals
        print "No of sinks", self.number_of_sinks
        
        self.backgroundRect = self.background.get_rect()
        screen.blit(self.background, self.backgroundRect) 
        
        
        
    def show_bkgnd(self):
        self.backgroundRect = self.background.get_rect()
        screen.blit(self.background, self.backgroundRect)   
       #screen.blit(self.north_pointer, [500,100])  
        #screen.blit(self.wind_arrow, [25,300]) 
        
#-----------------------------------------------------------------------        
    #~ def show_startup_box(self):
        #~ self.ltpos = 200
        #~ self.tvpos = 200

        #~ #pygame.draw.rect(screen, self.YELLOW, (100,100,700,600), 2)
        #~ #pygame.draw.circle(screen, color, (x,y), radius, thickness) 
        
        #~ self.position1 = [self.ltpos,self.tvpos-10]    # Position for line 1
        #~ self.position2 = [self.ltpos,self.tvpos+50]       
        #~ self.position3 = [self.ltpos,self.tvpos+75]
        #~ self.position4 = [self.ltpos,self.tvpos+100]
        #~ self.position5 = [self.ltpos,self.tvpos+125]
        #~ self.position6 = [self.ltpos,self.tvpos+275]
        
        #~ message1 = 'Thermalling Training Simulator'
        #~ message2 = 'To Turn Right Press             Right Arrow'
        #~ message3 = 'To Turn Left Press              Left Arrow'
        #~ message4 = 'Toggle Pause Simulation Press   p'
        #~ message5 = 'Toggle Thermal Visibility       t'
        #~ message6 = 'Press SPACE to continue'
        
        #~ text1 = self.font.render(message1, 1, self.YELLOW)
        #~ text2 = self.font.render(message2, 1, self.YELLOW)
        #~ text3 = self.font.render(message3, 1, self.YELLOW)
        #~ text4 = self.font.render(message4, 1, self.YELLOW)
        #~ text5 = self.font.render(message5, 1, self.YELLOW)
        #~ text6 = self.font.render(message6, 1, self.YELLOW)
        
        #~ screen.blit(text1, self.position1)
        #~ screen.blit(text2, self.position2)
        #~ screen.blit(text3, self.position3)
        #~ screen.blit(text4, self.position4)
        #~ screen.blit(text5, self.position5)
        #~ screen.blit(text6, self.position6)
#-----------------------------------------------------------------------          
    def show_menu(self):   
        self.ltpos = 125
        self.tvpos = 200
        message1 = '   Thermaling Training Simulator Control Keys'
        message2 = 'Up Arrow: Apply Speedbar  Apply Brakes    :Down Arrow'
        message3 = '<: Turn Left              Turn Right      :>'
        message4 = 'a: Toggle Audio           Throw reserve   :r'
        message5 = 't: Toggle thermal         Toggle sink     :s' 
        message6 = 'w: Toggle Wind Arrow      Big Ears        :e'  
        message7 = 'p: Pause                  Quit            :q'
        message8 = '+/=: Add a thermal        Add a sink      :-' 
        message9 = 'c: Collapse Wing          Recover Collapse:k' 
        message10= '           Press SPACE BAR to start' 
        
        text1 = self.font.render(message1, 1, self.YELLOW)
        text2 = self.font.render(message2, 1, self.YELLOW)
        text3 = self.font.render(message3, 1, self.YELLOW)
        text4 = self.font.render(message4, 1, self.YELLOW)
        text5 = self.font.render(message5, 1, self.YELLOW)
        text6 = self.font.render(message6, 1, self.YELLOW)
        text7 = self.font.render(message7, 1, self.YELLOW)
        text8 = self.font.render(message8, 1, self.YELLOW)
        text9 = self.font.render(message9, 1, self.YELLOW)
        text10= self.font.render(message10, 1, self.YELLOW)
        
        self.position1 = [self.ltpos,self.tvpos-10]    # Position for line 1
        self.position2 = [self.ltpos,self.tvpos+50]       
        self.position3 = [self.ltpos,self.tvpos+75]
        self.position4 = [self.ltpos,self.tvpos+100]
        self.position5 = [self.ltpos,self.tvpos+125]
        self.position6 = [self.ltpos,self.tvpos+150]
        self.position7 = [self.ltpos,self.tvpos+175]
        self.position8 = [self.ltpos,self.tvpos+200]
        self.position9 = [self.ltpos,self.tvpos+225]
        self.position10 = [self.ltpos,self.tvpos+275]
        
        screen.blit(text1, self.position1)
        screen.blit(text2, self.position2)
        screen.blit(text3, self.position3)
        screen.blit(text4, self.position4)
        screen.blit(text5, self.position5)
        screen.blit(text6, self.position6)
        screen.blit(text7, self.position7) 
        screen.blit(text8, self.position8) 
        screen.blit(text9, self.position9) 
        screen.blit(text10, self.position10) 
           
#-----------------------------------------------------------------------          
        
    def clear_messages(self):
        self.backgroundRect = self.background.get_rect()
        screen.blit(self.background, self.backgroundRect)
#-----------------------------------------------------------------------          

            
            
            
#-----------------------------------------------------------------------          
    def show_all_thermals(self,mythermallist):
        if flying_site.all_thermals_visible == True:
            for each_thermal in mythermallist:
                each_thermal.show()
        
#-----------------------------------------------------------------------          
    def show_all_sinks(self,mysinklist):  
        for each_sink in mysinklist:
            each_sink.show()          
#-----------------------------------------------------------------------  

    def game_over(self):
        print "Game Over"
        self.font = pygame.font.SysFont('FreeMono', 65, True, False)
        pygame.draw.rect(screen, self.YELLOW, (100,100,500,200), 2)
        message = 'Game Over'
        text = self.font.render(message, 1, self.YELLOW)
        self.position = [150,150] 
        screen.blit(text, self.position)
        


#-----------------------------------------------------------------------              
            
            
#-----------------------------------------------------------------------

class wind(object):
    '''The meterorological wind in our world'''
    def __init__(self):
        # Also set world parameters
        # Such as Windspeed, Direction etc which affect everything else
                
        self.description = "Simple wind simulation"
        self.author = "Chris"
        
        self.speed = random.random() * 5.0    # 5m/sec is about 14mph
        self.degrees = random.randint(0,360)
        
        # Direction (In Radians)
        self.direction = self.degrees *(math.pi/180.0)   
        
        self.gust = 0                           # m/sec
        self.lower_level = 20.0                 # Min height of wind (m)
        self.upper_level = 2000.0               # Top of wind
        #self.shear_rate = 0.01                  # Degrees per m height
        self.enabled = True
        self.wind_vane_visible = True           # Show wind vane 'W'
        self.wind_vane = pygame.image.load("resources/windvane.png")
        
        self.gust_factor = 1.0
        
        
    def rot_center(self,image, angle):
        """rotate an image while keeping its center and size"""
        orig_rect = image.get_rect()
        rot_image = pygame.transform.rotate(image, angle)
        rot_rect = orig_rect.copy()
        rot_rect.center = rot_image.get_rect().center
        rot_image = rot_image.subsurface(rot_rect).copy()
        return rot_image    
        
        
        
        
    def gust(self):
        # Generates a change in wind speed along with direction
        pass
        
    def change_direction(self,new_direction):
        # Changes the wind direction to a new direction
        # At random
        ctraj = (-180/math.pi*trajectory)+math.pi/4 
        self.this_player = self.rot_center(self.icon,ctraj)
        pass
        
    def show(self):
        if self.wind_vane_visible == True: 
            ctraj = (-180/math.pi*self.direction)+math.pi/4 
            rot = self.rot_center(self.wind_vane, ctraj)
            screen.blit(rot, [50,230])    

#-----------------------------------------------------------------------

class thermal(object):
    # NOTE:
    # The direction angles are in RADIANS.
    # ONE degree is approximately 0.01745 radians
    # A direction of ZERO radians is HORIZONTAL Left to Right --->
    # A direction of PI radians is HORIZONTAL Right to Left
    # A direction of PI/2 is VERTCALLY Downwards
    # A direction of 3*PI/2 is VERTICALLY Upwards
    # Screen size = [1527, 984] #
    global size
    #size = [1000, 800] # Default screen size
    
    def __init__(self):
        
        self.description = "A simple thermal model"
        self.author = "Chris"
        
        self.dx = random.randint(200,800)        # Set initial position
        self.dy = random.randint(200,600)        # Set initial position
        
        # Initial direction of travel
        self.direction = random.random()* math.pi*2
        self.speed = random.random()   # Drift speed of thermal
        
        # sets the lifetime of the thermal before it dies (@25fps)
        self.lifetime = random.random() * 25 *60 # Default = 60 seconds
        
        self.strength = random.random()*25*5.0    # Range 0 to 5 m/sec?
        self.visible = True            # Boolean
        self.diameter = 200.0            # Diameter
        self.top = 5000                # Altitude at top
        self.base = 300                # Base of bottom of thermal
       #self.drift_rate = 1.0 /25         # Drift rate
        
        self.icon = pygame.image.load("resources/thermal.png")
        self.position = self.icon.get_rect()
        self.position = self.position.move(self.dx,self.dy)
        
        
    def drift(self):
        # Moves the thermal according to WIND.speed 
        # and WIND.direction
        # Scale factor 0.8 of actual wind speed
        # But Pilot will experience full wind speed
        # So there will be differential drift between thermal and pilot
        # Factor = 70% (ie x0.7)
        self.dx += wind.speed * math.cos(wind.direction)*0.7/25
        self.dy += wind.speed * math.sin(wind.direction)*0.7/25
        self.position = self.icon.get_rect()
        self.position = self.position.move(self.dx,self.dy)

    def get_position(self):
        # Returns current position
        #return self.thermal_position    
        return self.dx, self.dy   
        
        
    def get_lift(self, distance):
        # A good thermal produces +5m/sec
        # Most are about +2 to +3
        # Some are only just above 1
        k = 5.0
        a = 1.0
        n = 0.7
        
        lift = k/(a*(math.pow(distance,n))) +1
        
        if (distance > 50):
            return 0
        else:
            return lift
            
    # Show the Thermal
    def show(self):
        #print "Thermal Position ", self.position
        self.lifetime -= 1 # Decrement lifetime counter
        
        if (self.lifetime <1):
            mythermallist.remove(self)
            return
            
        if (self.visible == True):
        #if flying_site.all_thermals_visible == True:
            screen.blit(self.icon, self.position)
            
            
    def generate_another_thermal(self):
        # Show number of thermals and sinks
        # Used later to automatically add extra ones
            #print "No Thermals",
            tt = len (mythermallist)
            #print "No Sinks",
            ss = len (mysinklist)
            if tt < flying_site.mnot:          # Max No Of Thermals
                mythermal = thermal()
                mythermallist.append(mythermal)            
            
#-----------------------------------------------------------------------            
            
class sink(thermal):
        # Inherits most of the same as the thermal class above
        
    def __init__(self):
        
        self.dx = random.randint(200,800)        # Set initial position
        self.dy = random.randint(200,600)        # Set initial position
        
        # sets the lifetime of the sink before it dies (@25fps)
        self.thermal_lifetime = random.random() * 25 *30
        
        self.strength = random.random() * 25 * 3.0    # Range 0 to 3
        self.visible = True            # Boolean
        self.diameter = 100            # Diameter
        self.top = 5000                # Altitude at top
        self.base = 300                # Base of bottom of thermal
        self.drift_rate = 1.0          # Drift rate
        
        # sets the lifetime before it dies (@25fps)
        self.lifetime = random.random() * 25 *30 # Default = 30
        
        self.icon = pygame.image.load("resources/sink.png")
        self.position = self.icon.get_rect()
        self.position = self.position.move(self.dx,self.dy)
        
    # Show Sink
    def show(self):
        #print "Thermal Position ", self.position
        self.lifetime -= 1 # Decrement lifetime counter
        
        if (self.lifetime <1):
            mysinklist.remove(self)
            return
            
        if (self.visible == True):
        #if flying_site.all_thermals_visible == True:
            screen.blit(self.icon, self.position)                

#-----------------------------------------------------------------------

class pilot(object):
    ''' Holds details of the pilot '''
    # NOTE:
    # The direction angles are in RADIANS.
    # ONE degree is approximately 0.01745 radians
    # A direction of ZERO radians is HORIZONTAL Left to Right --->
    # A direction of PI radians is HORIZONTAL Right to Left
    # A direction of PI/2 is VERTCALLY Downwards
    # A direction of 3*PI/2 is VERTICALLY Upwards
    
    def __init__(self):
        # Initial Configuration
        self.dx = random.randint(200,800)        # Set initial position
        self.dy = random.randint(200,600)        # Set initial position
        self.description = "The Pilot"
        self.visible = True                      # Boolean
        self.steerable = True                    # Boolean
        self.reserve_deployed = False
        self.bigears_pulled = False
        self.speedbar_active = False
        self.collapsed = False
        self.recovery_time = 3                   # Typical?
        
        # Initial direction of travel
        self.direction = random.random() *(math.pi*3/2.0) 
        
        # Variables
        self.airspeed = 10.8            # m/sec Speed of pilot 
        self.groundspeed = 0            # Default dummy value for init
        self.current_sink_rate = 1.0        # Current sink rate
        
        # Constants
        self.trim_speed =     10.8      # m/sec        
        self.speedbar_speed = 15.27     # m/sec
        self.min_sink_speed = 9.0       # m/sec
        self.sink_rate_trim =      1.0  # Trim sink rate m/sec
        self.sink_rate_on_bar =    1.5  # Accelerated Sink Rate
        self.sink_rate_min_speed = 1.2  # Braked Sink Rate
        self.glide_ratio = 10           # Init typical glide ratio
        self.reserve_sink_rate = 6.0    # m/sec typical
        self.bigears_sink_rate = 3.0    # m/sec
        self.bigears_sink_rate_on_bar = 4.0    # m/sec
        self.bigears_airspeed = 8.8     # m/sec typical
        self.bigears_airspeed_on_bar = 10.3 # Guess? 
        
        self.collapsed_airspeed = 0.5   # Very slow forward speed!
        self.collapsed_sink_rate = 12.0 # High sink rate
        self.spin_sink_rate = 11.3		# Just a guess
        self.collapse_lift_limit_on_bar = 2.5	# m/sec
        self.collapse_lift_limit = 3.0
        
        # Other
        self.bgdglider = pygame.image.load("resources/bgd-glider.png")  
        self.reserve = pygame.image.load("resources/reserve.png")  
        self.bgdears = pygame.image.load("resources/bigears.png")
        self.pgcollapsed = pygame.image.load("resources/pgcollapsed.png")
        
        self.icon = self.bgdglider
        
        self.position = (self.dx,self.dy) 
        self.altitude = 200.0        # 1000(m) Default Initial Altitude
          
        
        
        ctraj = (-180/math.pi*self.direction)+math.pi/4 
        self.this_player = self.rot_center(self.icon,ctraj)
           
   #def __del__(self):
   #     print "Deleted"       
                      
    def move(self,direction):
        # Moves the pilot according to speed and direction
        # Then calculate new position...and move there 
        # Note SCALE FACTOR for 25 FRAMES/SECOND
        
        trajectory = direction       
        ndx = self.airspeed * math.cos(trajectory)/25
        ndy = self.airspeed * math.sin(trajectory)/25
        
        # Then adjust for the prevailing wind speed vectors
        # Remember scale factors
        wx = wind.speed * math.cos(wind.direction)/25
        wy = wind.speed * math.sin(wind.direction)/25
        
        rx = ndx + wx
        ry = ndy + wy  
        self.groundspeed = math.sqrt(rx*rx + ry*ry) *25
        
        self.dx += rx
        self.dy += ry
        
        # Calculate glide ratio as groundspeed vs vario
        #pgpilot.glide_ratio = 8.3
        
        #~ print "Pilot Airspeed", self.airspeed
        #~ print "Pilot Vectors", self.dx, self.dy         
        #~ print "Wind Speed", wind.speed/25
        #~ print "Wind Vectors", wx,wy
        #~ print "Resultant Vectors",rx,ry
        #~ print "Pilot Groundspeed", self.groundspeed
        #~ print "Pilot Glide Ratio", self.glide_ratio
        #~ print
        
        self.position = self.icon.get_rect()
        self.position = self.position.move(self.dx,self.dy)
        
        # And rotate the paraglider so it is pointing 
        # in the correct direction...        
        # The new direction must relate to the current vectors px,py
        # theta = math.atan(self.py/self.px)
        # print "PX: ",self.px, "PY: ",self.py, "Theta: ",theta

        ctraj = (-180/math.pi*trajectory)+math.pi/4 
        self.this_player = self.rot_center(self.icon,ctraj)
                
    def get_position(self):
        # Returns current position
        #return self.pilot_position              
        return self.dx, self.dy        
                
    def rot_center(self,image, angle):
        """rotate an image while keeping its center and size"""
        orig_rect = image.get_rect()
        rot_image = pygame.transform.rotate(image, angle)
        rot_rect = orig_rect.copy()
        rot_rect.center = rot_image.get_rect().center
        rot_image = rot_image.subsurface(rot_rect).copy()
        return rot_image
        
    def update_heading(self,keypress):
        # Accepts a key '<' or '>' and adjusts pilot 'direction'
        # Needs to allow for application of Speedbar and Ears
        # SPDBAR + > or < runs at speedbar airspeed (assumes weight shifting)
        # EARS + < or > assumes speed at EARS speed
        # < or > at trim assumes TRIM SPEED
        
        # So assume you continue at same speed...
        
        if keypress == '<':
            self.direction -= 0.02
            
        if keypress == '>':
            self.direction += 0.02    

        self.move(self.direction)
        pgpilot.show_pilot()   
        
        return


        
    # If you have a very strong thermal, use of speedbar
    # can cause a collapse with a probability of say 5% (1:20)  
    # If distance from thermal < some number
    # And thermal < some number...
      
    def glider_collapse(self):
        self.recovery_time = random.random()*4      # Up to 4 seconds! 
        self.airspeed = self.collapsed_airspeed
        self.current_sink_rate = self.collapsed_sink_rate
        self.icon = self.pgcollapsed
        self.collapsed = True
        self.steerable = False
        
    # After a random time interval of 1 - 5 seconds
    # a glider will usually recover normal flight
    # self.recovery_time is generated randomly for each collapse
    # If collapse_timer > some random number < 5 seconds
    def glider_recovery(self):
        self.icon = self.bgdglider
        self.airspeed = self.min_sink_speed   
        self.current_sink_rate = self.sink_rate_min_speed 
        self.collapsed = False
        self.steerable = True
        
        
    def glider_rotate(self):
    # Causes rapid rotation similar to a spin 
    # Used for Reserve and collapse behaviour (not turning)
        self.direction += 0.15 # Quite fast
        #self.current_sink_rate = self.spin_sink_rate
            
        
    def update_altitude(self, vario_reading):
        self.altitude += vario_reading/25
        #print "Altitude: ", self.altitude

# Looks OK
    def apply_speedbar(self):
        self.speedbar_active = True
        if self.bigears_pulled == True:
            self.airspeed = self.bigears_airspeed_on_bar
            self.current_sink_rate = self.bigears_sink_rate_on_bar 
        else:
            self.airspeed = self.speedbar_speed   # OK
            self.current_sink_rate = self.sink_rate_on_bar    #1.5    
        
    def remove_speedbar(self): 
        self.speedbar_active = False  
        if self.bigears_pulled == True:
            self.airspeed = self.bigears_airspeed
            self.current_sink_rate = self.bigears_sink_rate
            
        else:
            self.airspeed = self.trim_speed       # OK
            self.current_sink_rate = self.sink_rate_trim       # 1.0
            self.icon = self.bgdglider
        
        
    def apply_trim_speed(self):
#        self.icon = self.bgdglider
 #       self.airspeed = self.min_sink_speed   #OK
  #      self.current_sink_rate = self.sink_rate_min_speed #1.2
        
        self.speedbar_active = False
        self.bigears_pulled = False
        self.icon = self.bgdglider
        self.airspeed = self.trim_speed 
        self.current_sink_rate = self.sink_rate_trim 
        
    def apply_both_brakes(self): 
        # Apply both brakes
        self.speedbar_active = False
        self.bigears_pulled = False
        self.icon = self.bgdglider
        self.airspeed = self.min_sink_speed
        self.current_sink_rate = self.sink_rate_min_speed
              
        
    def pull_big_ears(self):
        if self.bigears_pulled == False:
            # Initiate Big Ears
            self.bigears_pulled = True
            self.icon = self.bgdears
            
            if self.speedbar_active == True:
                self.airspeed = self.bigears_airspeed_on_bar
                self.current_sink_rate = self.bigears_sink_rate_on_bar
                
            if self.speedbar_active == False:
                self.airspeed = self.bigears_airspeed
                self.current_sink_rate = self.bigears_sink_rate
            
        else:
            # Return to normal flight
            self.speedbar_active = False
            self.bigears_pulled = False
            self.icon = self.bgdglider
            self.airspeed = self.trim_speed 
            self.current_sink_rate = self.sink_rate_trim  
            
            
                
    # Show the Pilot
    def show_pilot(self):
        if (self.visible == True):
            this_player = self.rot_center(self.icon,self.direction)
            screen.blit(self.this_player, self.position)
            #print "Pilot Position BLIT: ", self.position
            
    # Humorous function allowing a reserve deplyment
    def throw_reserve(self):
        self.icon = self.reserve
        self.sink_rate = 6.0        # m/sec sink rate
        self.steerable = False
        self.reserve_deployed = True
        self.airspeed = 0.1
        self.collapsed = False
        
        
        
    def query_collapse(self,va):
    # Simulation of a collapse  
    # If Lift is too strong generate a collapse
    # At 25fps and for one collapse per 10 miinutes
    # Luck must be small... 1/15000 or smaller
        luck = random.random() 
        if luck < 1.0/30000.0:
			self.glider_collapse() 
			
        
        if (va > self.collapse_lift_limit_on_bar)and(self.speedbar_active == True):   
            self.glider_collapse() 
            return 
           
        if va > self.collapse_lift_limit:
            self.glider_collapse()
            return    
        
       

#-----------------------------------------------------------------------
class variometer(object):
    # should this inherit from pilot ?
    #self.icon = pygame.image.load("resources/variometer.png")
    def __init__(self):
        self.YELLOW = (255,255,0)
        self.description = "A text-box variometer"
        self.author = "Chris"
        self.enabled = True
        self.audio_enabled = True
        self.audio_counter = 15         # Set beep rate every 15 frames
        
        self.visible = True
        self.dx = (20)        # Set initial x position
        self.dy = (20)        # Set initial y position
        
        # Select the font to use, size, bold, italics
        self.font = pygame.font.SysFont('Calibri', 25, True, False)
        self.description = "On screen text information"
        self.status_visible = False              # Boolean
        self.status_enabled = True
        self.max_alt = 99.9
        self.start_time = time.time()       # Get start time
        
        
        # Audio initialisation
        self.vario_sound_sink = pygame.mixer.Sound('resources/sink.ogg')
        self.vario_sound_001 = pygame.mixer.Sound('resources/climb001.ogg')
        self.vario_sound_002 = pygame.mixer.Sound('resources/climb002.ogg')
        self.vario_sound_003 = pygame.mixer.Sound('resources/climb003.ogg')
        self.vario_sound_004 = pygame.mixer.Sound('resources/climb004.ogg')
        self.vario_sound_005 = pygame.mixer.Sound('resources/climb005.ogg')
        self.vario_sound_006 = pygame.mixer.Sound('resources/climb006.ogg')
        self.vario_sound_007 = pygame.mixer.Sound('resources/climb007.ogg')
        self.vario_sound_008 = pygame.mixer.Sound('resources/climb008.ogg')
        self.vario_sound_009 = pygame.mixer.Sound('resources/climb009.ogg')
        self.vario_sound_010 = pygame.mixer.Sound('resources/pre-thermal.ogg')
        
#    def show(self,altitude,rate):   
    def show(self,pilotref,rate):   
        # vario.show(pgpilot.altitude,va) 
        # Shows the variometer on the background
        self.position1 = [25,25]        # Position for line 1
        self.position2 = [25,50]       # Position for line 2 etc...
        self.position3 = [25,75]
        self.position4 = [25,100]
        self.position5 = [25,125]
        self.position6 = [25,150]
        self.position7 = [25,175]
        self.position8 = [25,200]
        self.position9 = [25,225]
        self.nowtime = time.time()      # Get start time
        
        self.elapsedtime = self.nowtime - self.start_time 
        self.clocktime = time.strftime('%H:%M:%S',time.gmtime(self.elapsedtime))
        
        if (self.max_alt < pilotref.altitude):
            self.max_alt = pilotref.altitude
            
        trueairspeed = pilotref.airspeed
        
        # Calculate glide ratio as groundspeed vs vario
        # NB Positive means you are gliding DOWN
        # Negative means you are gliding into a climb...
        pgpilot.glide_ratio = pgpilot.groundspeed/pgpilot.current_sink_rate
        
        #ground_speed = trueairspeed
        truewindspeed = wind.speed
        
        message1 = 'Altitude:  %0.0f m'         % pilotref.altitude
        message2 = 'Duration: ' + self.clocktime
        message3 = 'Glide Ratio %0.1f '         % pgpilot.glide_ratio
        message4 = 'Vario:    %0.2f m/sec'      % rate
        message5 = 'Max Ht:   %0.0f m'          % self.max_alt
        message6 = 'Airspeed: %0.2f m/sec'      % trueairspeed
        message7 = 'Ground speed: %0.2f m/sec'  % pgpilot.groundspeed
        message8 = 'Wind speed: %0.2f m/sec'    % truewindspeed
        #message9 = 'Ground speed: %0.2f m/sec'     % ground_speed
        
        # You have to do it this way as you can only BILT a 'surface'
        text1 = self.font.render(message1, 1, self.YELLOW)
        text2 = self.font.render(message2, 1, self.YELLOW)
        text3 = self.font.render(message3, 1, self.YELLOW)
        text4 = self.font.render(message4, 1, self.YELLOW)
        text5 = self.font.render(message5, 1, self.YELLOW)
        text6 = self.font.render(message6, 1, self.YELLOW)
        text7 = self.font.render(message7, 1, self.YELLOW)
        text8 = self.font.render(message8, 1, self.YELLOW)
        #text9 = self.font.render(message9, 1, self.YELLOW)
        
        # Send it for display
        screen.blit(text1, self.position1)
        screen.blit(text2, self.position2)
        screen.blit(text3, self.position3)
        screen.blit(text4, self.position4)
        screen.blit(text5, self.position5)
        screen.blit(text6, self.position6)
        screen.blit(text7, self.position7)
        screen.blit(text8, self.position8)
        #screen.blit(text9, self.position9)
        
        
    def set_audio(self, rate):
        # Generates an appropriate audio tone
        # Depending upon vario lift/sink rate
        # Minimum climb at 0 m/sec
        # Maximum at +4m/sec
        # Sink alarm at -1.2m/sec
            
        if self.audio_enabled == True:
            # use self.audio_counter to trigger once every 15 frames
            if self.audio_counter > 0:
                self.audio_counter -= 1
                return
            self.audio_counter = self.audio_counter = 15
            
            # Generate tone based on variometer rate
            if (rate < -1.2):
                self.vario_sound_sink.play()
                
            # Or in lift, set proportional to lift

            if (rate > 4):
                self.vario_sound_009.play()
                self.audio_counter = self.audio_counter = 5
                return            
            if (rate  > 3.5):
                self.vario_sound_008.play()
                self.audio_counter = self.audio_counter = 7
                return       
            if (rate  > 3.0):
                self.vario_sound_007.play()
                self.audio_counter = self.audio_counter = 8
                return    
            if (rate  > 2.5):
                self.vario_sound_006.play()
                self.audio_counter = self.audio_counter = 9
                return
            if (rate  > 2.0):
                self.vario_sound_005.play()
                self.audio_counter = self.audio_counter = 10
                return    
            if (rate  > 1.5):
                self.vario_sound_004.play()
                self.audio_counter = self.audio_counter = 11
                return
            if (rate  > 1.0):
                self.vario_sound_003.play()
                self.audio_counter = self.audio_counter = 12
                return
            if (rate  > 0.5):
                self.vario_sound_002.play()
                self.audio_counter = self.audio_counter = 13
                return 
            if (rate  > 0.1):
                self.vario_sound_001.play()
                self.audio_counter = self.audio_counter = 15
                return    

            if (rate  > -0.7):
                self.vario_sound_010.play()
                self.audio_counter = self.audio_counter = 15
                return   


#-----------------------------------------------------------------------
# Normal Functions
#-----------------------------------------------------------------------

def get_keyboard_input():
    # Simply returns the keyboard key pressed    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.display.quit()
            pygame.quit()
    #----------------------------------------------------------- 
    # KEYBOARD
    #-----------------------------------------------------------    
    
    # Restore normal trim speed if not turning, braking or accelerating
        if event.type == pygame.KEYUP:  
            if event.key == pygame.K_UP:   
                return '$'
            elif event.key == pygame.K_DOWN:   
                return '$'         
            if event.key == pygame.K_RIGHT:
                return '$'
            if event.key == pygame.K_LEFT:
                return '$'
                 
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                return '<'
            elif event.key == pygame.K_RIGHT:
                return '>'
            elif event.key == pygame.K_DOWN:   
                return '%'     
            elif event.key == pygame.K_SPACE:    
                return ' '
                
            # Add Thermal (number pad)
            elif event.key == pygame.K_KP_PLUS:   
                return '+'
            # Add sink                      
            elif event.key == pygame.K_KP_MINUS:   
                return '-'         
            # Add Thermal (upper keyboard keys)
            elif event.key == pygame.K_EQUALS:   
                return '+'
            # Add sink                      
            elif event.key == pygame.K_MINUS:   
                return '-'                    
                
                
                
            # Adjust flying speed    
            elif event.key == pygame.K_UP:   
                return '@'                  
            elif event.key == pygame.K_DOWN:   
                return '~'                               
                
            elif event.key == pygame.K_a:   
                return 'a'
            elif event.key == pygame.K_b:   
                return 'b'
            elif event.key == pygame.K_c:   
                return 'c' 
            elif event.key == pygame.K_k:   
                return 'k'                 
            elif event.key == pygame.K_d:   
                return 'd'  
            elif event.key == pygame.K_e:   
                return 'e'      
                
            elif event.key == pygame.K_g:   
                return 'g'    
            elif event.key == pygame.K_t:   
                return 't'    
            elif event.key == pygame.K_p:   
                return 'p'     
            elif event.key == pygame.K_q:   
                return 'q'  
            elif event.key == pygame.K_r:   
                return 'r'              
            elif event.key == pygame.K_s:   
                return 's'              
            elif event.key == pygame.K_w:   
                return 'w'  
                
            # This only works for numerals above the alphabet keys
            # NOT the keypad
            elif event.key == pygame.K_1:   
                return '1'
            elif event.key == pygame.K_2:   
                return '2'
            elif event.key == pygame.K_3:   
                return '3' 
            elif event.key == pygame.K_4:   
                return '4'    
            elif event.key == pygame.K_5:   
                return '5'    
            elif event.key == pygame.K_6:   
                return '6'         
                
            # This works for the number pad    
          #  elif event.key == pygame.K_KP0:
          #      return '0'
            elif event.key == pygame.K_KP1:   
                return '1'
            elif event.key == pygame.K_KP2:   
                return '2'
            elif event.key == pygame.K_KP3:   
                return '3' 
            elif event.key == pygame.K_KP4:   
                return '4'    
            elif event.key == pygame.K_KP5:   
                return '5'    
            elif event.key == pygame.K_KP6:   
                return '6'             
    return '0'
#-----------------------------------------------------------------------                      
                    
def do_keyboard_action(pilot_ref, key):
    global running
    # Accept keyboard input    
    if key == 'p':
        # Toggle PAUSE
        if(running == True):
            running = False  
            # Pause clock time
            
        elif(running == False):
            running = True  
            # Re-enabled clock time
        

               
    if key == 't':
        # Toggle visibility of all thermals
        if flying_site.all_thermals_visible == True:
            flying_site.all_thermals_visible = False    
            
        elif flying_site.all_thermals_visible == False:
            flying_site.all_thermals_visible = True


    if key == 'w':
        # Toggle visibility wind indicator
        if wind.wind_vane_visible == True:
            wind.wind_vane_visible = False    
            
        elif wind.wind_vane_visible  == False:
            wind.wind_vane_visible  = True

    if key == 's':
        # Toggle visibility of all sinks
        for each_sink in mysinklist:
            if flying_site.all_sinks_visible == False:
                each_sink.visible = True
            else:
                each_sink.visible = False   
                flying_site.all_sinks_visible = False               
                
    if key == 'c':
        # Collapse Glider...
        pilot_ref.glider_collapse()
        
    if key == 'k':
        # Collapse Glider...
        pilot_ref.glider_recovery()    
       
       
    if key == '%':
        # Appply Both brakes
        pilot_ref.apply_both_brakes()                     

    if key == 'a':
        # Toggle audio sounds
        if vario.audio_enabled == True:
            vario.audio_enabled = False
        else:
            vario.audio_enabled = True
                
    if key == '+':
        if (len(mythermallist) < flying_site.mnot):
            mythermal = thermal()
            mythermallist.append(mythermal)
        
    if key == '-':
        if (len(mysinklist) < flying_site.mnos):
            mysink = sink()
            mysinklist.append(mysink)                            
        
        
    if key == 'e':
        # Pull Big Ears self.bgdears 
        pilot_ref.pull_big_ears()   
   
         
        
    if key == 'r':
        # Throw reserve
        pilot_ref.throw_reserve()
        pilot_ref.current_sink_rate = pilot_ref.reserve_sink_rate
        
        if key == 'g':
        # Start New Game
            print "Starting new game"

        
    if key == '@':
        # Apply speedbar
        pilot_ref.apply_speedbar()

            

        
    if key == '~':
        pilot_ref.apply_trim_speed()
        # Brake to minimum speed 
        # but depends on whether bigears are pulled too
        # See line 564

                
                
        # Return to trim speed        
    if key == '$':
        pilot_ref.remove_speedbar()


                
    if key == 'q':
        # Quit
        pygame.display.quit()
        pygame.quit()
        

#-----------------------------------------------------------------------  
    
        
def calculate_net_lift(mythermallist):
    # A good thermal produces +5m/sec
    # Most are about +2 to +3
    # Some are only just above 1
    k = 5.0 # Scale factor for thermal strength
    #a = 1.0 # Scale factor for approach distance
    n = 0.7
    lift = 0
    #i = 0
    dx = 0
    dy = 0
    dd = 0.0 
    
    total_lift = 0          # Initialise as zero lift contribution

    px,py = pgpilot.get_position()
    #print "Pilot Position = ", px, py
    
    for each_thermal in mythermallist:
        # DEBUG...
        #i += 1  # Maintain counter for debug purposes only
        #print "Thermal",i,"Position ",each_thermal.get_position()
        
        # CALCULATION OF SEPARATION...
        tx,ty = each_thermal.get_position()
        dx = px-tx
        dy = py-ty
        
        dd = math.sqrt(abs(dx*dx + dy*dy)) # Avoid root of -ve number!
        
        #print 'Separation: ', dd
        #print 'Thermal Position', tx,ty
        #message4 = 'Vario:    %0.2f m/sec' % rate
        #print 'Thermal Distance: %0.0f' % dd
        
        diam = each_thermal.diameter
        
        # CALCULATE LIFT FROM THIS THERMAL
        if (dd < diam):
            lift = (-1.0* dd * each_thermal.strength/diam)+ each_thermal.strength
        else:
            lift = 0    
        
        total_lift += lift
        
    total_lift = total_lift/25
    #print "Total Thermic Lift: %0.2f" % total_lift
     #total_lift    

    return total_lift
#-----------------------------------------------------------------------              

            
            
#-----------------------------------------------------------------------              
        
def calculate_net_sink(mysinklist):
    i = 0
    dx = 0
    dy = 0
    dd = 0.0 
    sink = 0.0
    total_sink = 0.0    
    
    px,py = pgpilot.get_position()
    
    for each_sink in mysinklist:    
        # CALCULATION OF SEPARATION...
        tx,ty = each_sink.get_position()
        dx = px-tx
        dy = py-ty
        dd = math.sqrt(abs(dx*dx + dy*dy)) # Avoid root of -ve number!
        #print "Sink Separation: ", dd
        diam = each_sink.diameter
        
        # Calculate Sink from this sink
        if (dd < diam):
            sink = (-1.0* dd * each_sink.strength/diam)+ each_sink.strength
        else:
            sink = 0    
        
        total_sink += sink/25
                
    #print "Total Sink: ", total_sink

    return total_sink
            
def calculate_vario_reading(mythermallist, mysinklist):
    # Note this is scaled for refresh of 25 fps
    resultant = 0.0
    up= calculate_net_lift(mythermallist)
    down = calculate_net_sink(mysinklist)
    glide = pgpilot.current_sink_rate 
        
    #print up,down,glide
    resultant = up - down - glide
    
    #print "Resultant Vario:", resultant
    return resultant
    
    
    
def generate_another_thermal():
    # Show number of thermals and sinks
    # Used later to automatically add extra ones
    counter+=1
    if counter > 30:
        print "No Thermals",
        tt = len (mythermallist)
        print "No Sinks",
        s = len (mysinklist)
        if tt < 3:
            mythermal = thermal()
            mythermallist.append(mythermal)
#-----------------------------------------------------------------------          
#-----------------------------------------------------------------------  
  
  
  
#========================================================
# MAIN APPLICATION
#========================================================
va = 0.0

print "starting game"
# Initialize Python Audio System to remove delays
pygame.mixer.pre_init(44100, -16, 2, 2048) # setup mixer

# initialize game engine
pygame.init()
pygame.key.set_repeat(10) # Enables auto repeat from keyboard

# set screen width/height and caption FIXED SIZES
global size
size = [1000, 700] # Default should fit most modern monitors

screen = pygame.display.set_mode(size)

title_text = 'Thermaling Training Simulator by Chris Leaver'
pygame.display.set_caption(title_text)



#========================================================
# START REPLAYS FROM HERE IF NEEDED
#========================================================



clock = pygame.time.Clock()


# Create an instance of our world
flying_site = world() 
# Setup wind
wind = wind()

# Create an instance of the startup box
pygame.display.update()

vario = variometer()

#-----------------------------------------------------------------------
# Start Up Messages
#-----------------------------------------------------------------------

# Now remove startup messages
flying_site.clear_messages()
flying_site.show_menu()

# Await Keybard key press before continuing

pygame.display.update() # Show the messages
kb = '0'
while (kb == '0'):
    kb = get_keyboard_input() # Get menu Option 1,2,3,4,5
print "Selected ",kb    

#-----------------------------------------------------------------------


#========================================================
# END OF SETUP, NOW STARTING ACTUAL GAME
#========================================================

#-----------------------------------------------------------------------
# Generate a selection of thermals
mythermallist = list()
i = flying_site.number_of_thermals

while (i > 0):
    mythermal = thermal()
    mythermallist.append(mythermal)
    i = i-1

#-----------------------------------------------------------------------


# And a selection of sinks
mysinklist=list()
i = flying_site.number_of_sinks

#print "No of Sinks = ", i
while (i > 0):
    mysink = sink()
    mysinklist.append(mysink)
    i = i-1

#-----------------------------------------------------------------------
# Now initialise the pilot
pgpilot = pilot()
pgpilot.show_pilot()    # Works

#-----------------------------------------------------------------------
counter = 0

running = True

while(True):
    kb = get_keyboard_input() 
    do_keyboard_action(pgpilot,kb) # Action the event_handler (keyboard?)
    
    while (running == True):          
        if pgpilot.steerable == True: 
            inputkey = get_keyboard_input()   
        # But only action the keyboard input if not locked out
        else:
            inputkey = get_keyboard_input() 
            
            # Throw Reserve
            if inputkey == 'r': 
                do_keyboard_action(pgpilot,inputkey)
                
            # Attempt recovery    
            if inputkey == 'k' and pgpilot.collapsed == True:
                do_keyboard_action(pgpilot,inputkey)
                
                
            else:       
                inputkey = '' 
                pgpilot.glider_rotate()
            
        do_keyboard_action(pgpilot,inputkey)    
            
            
            
        # Refresh Background BEFORE adding the extra graphics
        flying_site.show_bkgnd()                            # Works
        flying_site.show_all_thermals(mythermallist)        # Works
        flying_site.show_all_sinks(mysinklist)              # Works
        wind.show()                           # Just show Wind vane
        
        # Calculate resultant of all thermals, sinks and glider sink rate
        va = calculate_vario_reading(mythermallist, mysinklist)
        
       
        # Update current glider attributes
        pgpilot.update_altitude(va)
        pgpilot.update_heading(inputkey)    
        
        # Update Thermal Positions to allow for drift with the wind 
        for each_thermal in mythermallist:  
            each_thermal.drift()
        
        # Update Sink Positions to allow for drift with the wind 
        for each_sink in mysinklist:  
            each_sink.drift()
        
        # Randomly generate a collapse in strong lift
        pgpilot.query_collapse(va) 
        
        # Show Variometer Display
        vario.show(pgpilot,va)      # Vario Display Data
        vario.set_audio(va)         # Audio Output
        wind.show()                 # Wind direction Arrow        


        # pgpilot.glider_rotate()  # Triggered by excessive thermals
            

        # To Do:
        # If Altitude < 5: GAME OVER 
        if pgpilot.altitude < 10:
            flying_site.show_bkgnd()
            pgpilot.update_heading(inputkey)
            flying_site.game_over()
            
            running = False


        # Update Display...
        pygame.display.update()
        # run at 25 fps0
        clock.tick(25)

#~ # close the window and quit
pygame.display.quit()
pygame.quit()
#========================================================

#========================================================
    
    
    
